SYCHO v1.1.9 - BIG update
=========================
NEW: Fullscreen (F11), 5 languages, Expense Tracker, World Clock, Unit Converter,
Pomodoro Timer, To-Do, Notes, Calculator, live clock.

RUN: python run.py
BUILD EXE: pyinstaller --noconsole --onefile --name SYCHO run.py
Open: dist\SYCHO.exe

UPDATE: zip SYCHO.exe -> upload GitHub -> bump manifest version/url.
