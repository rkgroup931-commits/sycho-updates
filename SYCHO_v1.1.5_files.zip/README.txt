SYCHO v1.1.5 - DAILY BRIEFING + LIFE TOOLS

New: Today briefing, habit tracker with streaks, diary, encrypted password vault, countdowns, currency converter, text tools, note search.

Build:
pip install --default-timeout=100 --retries 10 -r requirements.txt pyinstaller
pyinstaller --noconsole --onefile --name SYCHO run.py
Open dist\SYCHO.exe
