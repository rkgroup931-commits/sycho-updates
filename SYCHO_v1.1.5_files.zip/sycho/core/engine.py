import os, shutil, json
from .config import Config
from ..data.memory import EncryptedMemory
from ..data.reminders import Reminders
from ..data.notes import Notes
from ..data.tasks import Tasks
from ..data.clipboard import ClipboardHistory
from ..data.expenses import Expenses
from ..data.habits import Habits
from ..data.diary import Diary
from ..data.vault_entries import VaultEntries
from ..data.countdowns import Countdowns
from ..security.vault import Vault
from ..security.crypto import CryptoBox
from ..security.audit import AuditLog
from ..updater.updater import Updater

MEMORY_PATH = os.path.expanduser("~/.sycho/memory.enc")

class SychoEngine:
    def __init__(self, config):
        self.config = config
        self.vault = Vault()
        self.audit = AuditLog()
        self.updates = Updater()
        self.crypto = None
        self.memory = None
        self.reminder_store = Reminders()
        self.notes = Notes()
        self.tasks = Tasks()
        self.clipboard = ClipboardHistory()
        self.expenses = Expenses()
        self.habits = Habits()
        self.diary = Diary()
        self.vault_entries = VaultEntries()
        self.countdowns = Countdowns()

    def create_vault(self, passcode):
        self.vault.create(passcode)
        self.crypto = CryptoBox(passcode)
        self.memory = EncryptedMemory(self.crypto)
        self.audit.add("vault_created")

    def unlock(self, passcode):
        if not self.vault.verify(passcode):
            self.audit.add("vault_unlock_failed")
            return False
        self.crypto = CryptoBox(passcode)
        self.memory = EncryptedMemory(self.crypto)
        self.audit.add("vault_unlocked")
        return True

    def remember(self, text):
        if self.memory:
            self.memory.add(text)
            self.audit.add("memory_add")

    def all_memory(self):
        return self.memory.items if self.memory else []

    def delete_memory(self, text):
        if self.memory:
            self.memory.delete(text)
            self.audit.add("memory_delete")

    def save_note(self, title, body):
        self.notes.save(title, body)
        self.audit.add("note_saved", title=title)

    def get_notes(self):
        return self.notes.items

    def delete_note(self, title):
        self.notes.delete(title)
        self.audit.add("note_deleted", title=title)

    def add_task(self, text):
        self.tasks.add(text)
        self.audit.add("task_added")

    def get_tasks(self):
        return self.tasks.items

    def complete_task(self, index):
        self.tasks.complete(index)
        self.audit.add("task_completed")

    def delete_task(self, index):
        self.tasks.delete(index)
        self.audit.add("task_deleted")

    def add_reminder(self, title, when):
        self.reminder_store.add(title, when)
        self.audit.add("reminder_add", title=title)

    def get_reminders(self):
        return self.reminder_store.items

    def clipboard_history(self):
        return self.clipboard.items

    def add_clipboard(self, text):
        self.clipboard.add(text)

    def add_expense(self, description, amount):
        self.expenses.add(description, amount)
        self.audit.add("expense_added")

    def get_expenses(self):
        return self.expenses.items

    def add_habit(self, name):
        self.habits.add(name)
        self.audit.add("habit_added")

    def get_habits(self):
        return self.habits.items

    def habit_done_today(self, index):
        self.habits.mark_done_today(index)
        self.audit.add("habit_done")

    def delete_habit(self, index):
        self.habits.delete(index)
        self.audit.add("habit_deleted")

    def save_diary(self, text):
        self.diary.save_today(text)
        self.audit.add("diary_saved")

    def get_diary(self):
        return self.diary.items

    def add_vault_entry(self, site, user, password):
        if self.crypto:
            enc = self.crypto.encrypt(password).decode()
            self.vault_entries.add(site, user, enc)
            self.audit.add("vault_entry_added")

    def get_vault_entries(self):
        return self.vault_entries.items

    def reveal_vault_password(self, entry):
        if self.crypto:
            return self.crypto.decrypt(entry["password_enc"].encode())
        return ""

    def delete_vault_entry(self, index):
        self.vault_entries.delete(index)
        self.audit.add("vault_entry_deleted")

    def add_countdown(self, name, date):
        self.countdowns.add(name, date)
        self.audit.add("countdown_added")

    def get_countdowns(self):
        return self.countdowns.items

    def set_language(self, code):
        self.config.language = code
        self.config.save()
        self.audit.add("language_changed", language=code)

    def backup(self, folder):
        os.makedirs(folder, exist_ok=True)
        if os.path.exists(MEMORY_PATH):
            shutil.copy2(MEMORY_PATH, os.path.join(folder, "memory_backup.enc"))
        self.audit.add("backup_created", folder=folder)

    def restore(self, backup_file):
        shutil.copy2(backup_file, MEMORY_PATH)
        if self.memory and self.crypto:
            self.memory = EncryptedMemory(self.crypto)
        self.audit.add("backup_restored")

    def emergency_stop(self):
        self.audit.add("emergency_stop")
        if self.memory:
            self.memory.close()
        self.reminder_store.close()
        self.notes.close()
        self.tasks.close()
