import json, os
from datetime import date

PATH = os.path.expanduser("~/.sycho/habits.json")

class Habits:
    def __init__(self):
        self.items = []
        if os.path.exists(PATH):
            with open(PATH, encoding="utf-8") as f:
                self.items = json.load(f)

    def add(self, name):
        self.items.append({"name": name, "done_days": [], "streak": 0})
        self._save()

    def mark_done_today(self, index):
        if 0 <= index < len(self.items):
            today = date.today().isoformat()
            hb = self.items[index]
            if today not in hb["done_days"]:
                hb["done_days"].append(today)
                hb["streak"] = hb.get("streak", 0) + 1
            self._save()

    def delete(self, index):
        if 0 <= index < len(self.items):
            del self.items[index]
            self._save()

    def close(self):
        self._save()

    def _save(self):
        os.makedirs(os.path.dirname(PATH), exist_ok=True)
        with open(PATH, "w", encoding="utf-8") as f:
            json.dump(self.items, f, indent=2)
