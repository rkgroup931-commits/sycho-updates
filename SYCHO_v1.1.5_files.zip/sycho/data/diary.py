import json, os
from datetime import date

PATH = os.path.expanduser("~/.sycho/diary.json")

class Diary:
    def __init__(self):
        self.items = []
        if os.path.exists(PATH):
            with open(PATH, encoding="utf-8") as f:
                self.items = json.load(f)

    def save_today(self, text):
        today = date.today().isoformat()
        for entry in self.items:
            if entry["date"] == today:
                entry["text"] = text
                self._save()
                return
        self.items.append({"date": today, "text": text})
        self._save()

    def close(self):
        self._save()

    def _save(self):
        os.makedirs(os.path.dirname(PATH), exist_ok=True)
        with open(PATH, "w", encoding="utf-8") as f:
            json.dump(self.items, f, indent=2)
