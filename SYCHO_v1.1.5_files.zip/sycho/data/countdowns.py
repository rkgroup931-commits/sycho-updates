import json, os

PATH = os.path.expanduser("~/.sycho/countdowns.json")

class Countdowns:
    def __init__(self):
        self.items = []
        if os.path.exists(PATH):
            with open(PATH, encoding="utf-8") as f:
                self.items = json.load(f)

    def add(self, name, date):
        self.items.append({"name": name, "date": date})
        self._save()

    def close(self):
        self._save()

    def _save(self):
        os.makedirs(os.path.dirname(PATH), exist_ok=True)
        with open(PATH, "w", encoding="utf-8") as f:
            json.dump(self.items, f, indent=2)
