import json, os

PATH = os.path.expanduser("~/.sycho/vault_entries.json")

class VaultEntries:
    def __init__(self):
        self.items = []
        if os.path.exists(PATH):
            with open(PATH, encoding="utf-8") as f:
                self.items = json.load(f)

    def add(self, site, user, password_enc):
        self.items.append({"site": site, "user": user, "password_enc": password_enc})
        self._save()

    def delete(self, index):
        if 0 <= index < len(self.items):
            del self.items[index]
            self._save()

    def close(self):
        self._save()

    def _save(self):
        os.makedirs(os.path.dirname(PATH), exist_ok=True)
        with open(PATH, "w", encoding="utf-8") as f:
            json.dump(self.items, f, indent=2)
