SYCHO v1.1.2 - CRASH FIXED

The crash was: QTimer was imported from PySide6.QtWidgets, but it lives in PySide6.QtCore.
This is now fixed.

New: Quick Launch tab (YouTube, Gmail, GitHub, ChatGPT, Maps, Weather, custom websites).

Build:
pip install --default-timeout=100 --retries 10 -r requirements.txt pyinstaller
pyinstaller --noconsole --onefile --name SYCHO run.py
Open dist\SYCHO.exe

Delete old build and dist folders first.
