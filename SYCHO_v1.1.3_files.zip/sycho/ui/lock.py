from PySide6.QtWidgets import QDialog, QVBoxLayout, QLabel, QLineEdit, QPushButton
from ..core.engine import SychoEngine
from .hud import SychoHud

class LockScreen(QDialog):
    def __init__(self, engine, first_time=False):
        super().__init__()
        self.engine = engine
        self.first_time = first_time
        self.setWindowTitle("SYCHO v1.1.3 - Lock")
        layout = QVBoxLayout(self)
        self.label = QLabel("Create a SYCHO passcode" if first_time else "Enter SYCHO passcode")
        self.passcode = QLineEdit()
        self.passcode.setEchoMode(QLineEdit.Password)
        self.error = QLabel("")
        button = QPushButton("Create SYCHO" if first_time else "Unlock SYCHO")
        button.clicked.connect(self.try_unlock)
        for w in [self.label, self.passcode, self.error, button]:
            layout.addWidget(w)

    def try_unlock(self):
        code = self.passcode.text()
        if len(code) < 4:
            self.error.setText("Use at least 4 characters.")
            return
        if self.first_time:
            self.engine.create_vault(code)
        elif not self.engine.unlock(code):
            self.error.setText("Wrong passcode.")
            return
        self.hud = SychoHud(self.engine)
        self.hud.show()
        self.accept()
