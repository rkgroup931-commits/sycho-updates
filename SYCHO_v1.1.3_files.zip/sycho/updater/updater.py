import json, os, urllib.request, hashlib, zipfile

DEFAULT_MANIFEST_URL = "https://rkgroup931-commits.github.io/sycho-updates/manifest.json"

class Updater:
    def __init__(self, manifest_url=None):
        self.manifest_url = manifest_url or DEFAULT_MANIFEST_URL

    def check(self, timeout=15):
        try:
            with urllib.request.urlopen(self.manifest_url, timeout=timeout) as r:
                return json.loads(r.read().decode("utf-8"))
        except Exception:
            return None

    def download(self, url, destination, expected_sha256=None, timeout=60):
        os.makedirs(os.path.dirname(destination) or ".", exist_ok=True)
        with urllib.request.urlopen(url, timeout=timeout) as r, open(destination, "wb") as f:
            f.write(r.read())
        if expected_sha256:
            h = hashlib.sha256()
            with open(destination, "rb") as f:
                h.update(f.read())
            if h.hexdigest().lower() != expected_sha256.lower():
                os.remove(destination)
                raise ValueError("Update checksum mismatch.")
        return destination

    def install(self, update_zip, target_folder):
        os.makedirs(target_folder, exist_ok=True)
        with zipfile.ZipFile(update_zip) as z:
            if z.testzip():
                raise ValueError("Update package is corrupted.")
            z.extractall(target_folder)
        return target_folder
