SYCHO v1.1.3

New: auto update check on startup, stopwatch, Google web search, export notes to TXT.
Update manifest is pre-filled with your GitHub address.

Build:
pip install --default-timeout=100 --retries 10 -r requirements.txt pyinstaller
pyinstaller --noconsole --onefile --name SYCHO run.py
Open dist\SYCHO.exe

Delete old build and dist folders first.
