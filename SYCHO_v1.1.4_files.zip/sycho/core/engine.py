import os, shutil
from .config import Config
from ..data.memory import EncryptedMemory
from ..data.reminders import Reminders
from ..data.notes import Notes
from ..data.tasks import Tasks
from ..data.clipboard import ClipboardHistory
from ..data.expenses import Expenses
from ..security.vault import Vault
from ..security.crypto import CryptoBox
from ..security.audit import AuditLog
from ..updater.updater import Updater

MEMORY_PATH = os.path.expanduser("~/.sycho/memory.enc")

class SychoEngine:
    def __init__(self, config):
        self.config = config
        self.vault = Vault()
        self.audit = AuditLog()
        self.updates = Updater()
        self.crypto = None
        self.memory = None
        self.reminder_store = Reminders()
        self.notes = Notes()
        self.tasks = Tasks()
        self.clipboard = ClipboardHistory()
        self.expenses = Expenses()

    def create_vault(self, passcode):
        self.vault.create(passcode)
        self.crypto = CryptoBox(passcode)
        self.memory = EncryptedMemory(self.crypto)
        self.audit.add("vault_created")

    def unlock(self, passcode):
        if not self.vault.verify(passcode):
            self.audit.add("vault_unlock_failed")
            return False
        self.crypto = CryptoBox(passcode)
        self.memory = EncryptedMemory(self.crypto)
        self.audit.add("vault_unlocked")
        return True

    def remember(self, text):
        if self.memory:
            self.memory.add(text)
            self.audit.add("memory_add")

    def all_memory(self):
        return self.memory.items if self.memory else []

    def delete_memory(self, text):
        if self.memory:
            self.memory.delete(text)
            self.audit.add("memory_delete")

    def save_note(self, title, body):
        self.notes.save(title, body)
        self.audit.add("note_saved", title=title)

    def get_notes(self):
        return self.notes.items

    def delete_note(self, title):
        self.notes.delete(title)
        self.audit.add("note_deleted", title=title)

    def add_task(self, text):
        self.tasks.add(text)
        self.audit.add("task_added")

    def get_tasks(self):
        return self.tasks.items

    def complete_task(self, index):
        self.tasks.complete(index)
        self.audit.add("task_completed")

    def delete_task(self, index):
        self.tasks.delete(index)
        self.audit.add("task_deleted")

    def add_reminder(self, title, when):
        self.reminder_store.add(title, when)
        self.audit.add("reminder_add", title=title)

    def get_reminders(self):
        return self.reminder_store.items

    def clipboard_history(self):
        return self.clipboard.items

    def add_clipboard(self, text):
        self.clipboard.add(text)

    def add_expense(self, description, amount):
        self.expenses.add(description, amount)
        self.audit.add("expense_added")

    def get_expenses(self):
        return self.expenses.items

    def set_language(self, code):
        self.config.language = code
        self.config.save()
        self.audit.add("language_changed", language=code)

    def backup(self, folder):
        os.makedirs(folder, exist_ok=True)
        if os.path.exists(MEMORY_PATH):
            shutil.copy2(MEMORY_PATH, os.path.join(folder, "memory_backup.enc"))
        self.audit.add("backup_created", folder=folder)

    def restore(self, backup_file):
        shutil.copy2(backup_file, MEMORY_PATH)
        if self.memory and self.crypto:
            self.memory = EncryptedMemory(self.crypto)
        self.audit.add("backup_restored")

    def emergency_stop(self):
        self.audit.add("emergency_stop")
        if self.memory:
            self.memory.close()
        self.reminder_store.close()
        self.notes.close()
        self.tasks.close()
