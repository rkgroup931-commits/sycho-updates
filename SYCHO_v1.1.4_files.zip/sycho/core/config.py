import json, os
from dataclasses import dataclass, asdict

CONFIG_PATH = os.path.expanduser("~/.sycho/config.json")

@dataclass
class Config:
    language: str = "en"
    theme: str = "dark"
    update_channel: str = "stable"

    @classmethod
    def load(cls):
        if os.path.exists(CONFIG_PATH):
            with open(CONFIG_PATH, encoding="utf-8") as f:
                return cls(**json.load(f))
        return cls()

    def save(self):
        os.makedirs(os.path.dirname(CONFIG_PATH), exist_ok=True)
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(asdict(self), f, indent=2)
