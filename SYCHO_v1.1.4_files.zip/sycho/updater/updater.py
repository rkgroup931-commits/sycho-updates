import json, os, urllib.request, hashlib, zipfile

DEFAULT_MANIFEST_URL = "https://rkgroup931-commits.github.io/sycho-updates/manifest.json"
LATEST_FOLDER = os.path.expanduser("~/.sycho/latest")

class Updater:
    def __init__(self, manifest_url=None):
        self.manifest_url = manifest_url or DEFAULT_MANIFEST_URL
        self.latest_folder = LATEST_FOLDER

    def check(self, timeout=15):
        try:
            with urllib.request.urlopen(self.manifest_url, timeout=timeout) as r:
                return json.loads(r.read().decode("utf-8"))
        except Exception:
            return None

    def download_and_install(self, url, expected_sha256=None, progress=None, timeout=120):
        os.makedirs(self.latest_folder, exist_ok=True)
        zip_path = os.path.join(self.latest_folder, "update_package.zip")
        if progress:
            progress.setValue(20)
        with urllib.request.urlopen(url, timeout=timeout) as r, open(zip_path, "wb") as f:
            f.write(r.read())
        if progress:
            progress.setValue(60)
        if expected_sha256:
            h = hashlib.sha256()
            with open(zip_path, "rb") as f:
                h.update(f.read())
            if h.hexdigest().lower() != expected_sha256.lower():
                os.remove(zip_path)
                raise ValueError("Update checksum mismatch.")
        if progress:
            progress.setValue(80)
        with zipfile.ZipFile(zip_path) as z:
            if z.testzip():
                raise ValueError("Update package is corrupted.")
            z.extractall(self.latest_folder)
        if progress:
            progress.setValue(100)
        return self.latest_folder
