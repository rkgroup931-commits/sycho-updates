import sys
from PySide6.QtWidgets import QApplication
from .ui.hud import SychoHud
from .ui.lock import LockScreen
from .core.engine import SychoEngine
from .core.config import Config

def start():
    app = QApplication(sys.argv)
    config = Config.load()
    engine = SychoEngine(config)
    lock = LockScreen(engine, first_time=not engine.vault.exists())
    lock.show()
    sys.exit(app.exec())
