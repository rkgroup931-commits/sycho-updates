import json, os

PATH = os.path.expanduser("~/.sycho/notes.json")

class Notes:
    def __init__(self):
        self.items = []
        if os.path.exists(PATH):
            with open(PATH, encoding="utf-8") as f:
                self.items = json.load(f)

    def save(self, title, body):
        for note in self.items:
            if note["title"] == title:
                note["body"] = body
                self._save()
                return
        self.items.append({"title": title, "body": body})
        self._save()

    def delete(self, title):
        self.items = [n for n in self.items if n["title"] != title]
        self._save()

    def close(self):
        self._save()

    def _save(self):
        os.makedirs(os.path.dirname(PATH), exist_ok=True)
        with open(PATH, "w", encoding="utf-8") as f:
            json.dump(self.items, f, indent=2)
