import json, os
from ..security.crypto import CryptoBox

PATH = os.path.expanduser("~/.sycho/memory.enc")

class EncryptedMemory:
    def __init__(self, crypto):
        self.crypto = crypto
        self.items = []
        if os.path.exists(PATH):
            with open(PATH, "rb") as f:
                data = f.read()
            try:
                self.items = json.loads(self.crypto.decrypt(data))
            except Exception:
                self.items = []

    def add(self, text):
        self.items.append({"text": text})
        self._save()

    def delete(self, text):
        self.items = [i for i in self.items if i.get("text") != text]
        self._save()

    def search(self, query):
        q = query.lower()
        return [i for i in self.items if q in i.get("text", "").lower()]

    def close(self):
        self._save()

    def _save(self):
        os.makedirs(os.path.dirname(PATH), exist_ok=True)
        with open(PATH, "wb") as f:
            f.write(self.crypto.encrypt(json.dumps(self.items)))
