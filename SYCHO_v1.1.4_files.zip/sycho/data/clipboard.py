import json, os

PATH = os.path.expanduser("~/.sycho/clipboard_history.json")

class ClipboardHistory:
    def __init__(self):
        self.items = []
        if os.path.exists(PATH):
            with open(PATH, encoding="utf-8") as f:
                self.items = json.load(f)

    def add(self, text):
        if text and (not self.items or self.items[0] != text):
            self.items.insert(0, text)
            self.items = self.items[:20]
            self._save()

    def _save(self):
        os.makedirs(os.path.dirname(PATH), exist_ok=True)
        with open(PATH, "w", encoding="utf-8") as f:
            json.dump(self.items, f, indent=2)
