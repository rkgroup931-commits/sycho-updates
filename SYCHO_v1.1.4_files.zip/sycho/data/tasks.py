import json, os

class Tasks:
    def __init__(self):
        self.items = []
        self.path = os.path.expanduser("~/.sycho/tasks.json")
        if os.path.exists(self.path):
            with open(self.path, encoding="utf-8") as f:
                self.items = json.load(f)

    def add(self, text):
        self.items.append({"text": text, "done": False})
        self._save()

    def complete(self, index):
        if 0 <= index < len(self.items):
            self.items[index]["done"] = True
            self._save()

    def delete(self, index):
        if 0 <= index < len(self.items):
            del self.items[index]
            self._save()

    def close(self):
        self._save()

    def _save(self):
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump(self.items, f, indent=2)
