import json, os
from datetime import datetime, timezone

PATH = os.path.expanduser("~/.sycho/audit.jsonl")

class AuditLog:
    def add(self, event, **details):
        os.makedirs(os.path.dirname(PATH), exist_ok=True)
        with open(PATH, "a", encoding="utf-8") as f:
            f.write(json.dumps({"event": event, "details": details, "time": datetime.now(timezone.utc).isoformat()}) + "\n")
