import base64, hashlib
from cryptography.fernet import Fernet

class CryptoBox:
    def __init__(self, passcode):
        key = hashlib.pbkdf2_hmac("sha256", passcode.encode(), b"sycho-v1-static-salt", 310000)
        self.fernet = Fernet(base64.urlsafe_b64encode(key))

    def encrypt(self, text):
        return self.fernet.encrypt(text.encode())

    def decrypt(self, data):
        return self.fernet.decrypt(data).decode()
