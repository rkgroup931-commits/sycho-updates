import os, json, hashlib, secrets

PATH = os.path.expanduser("~/.sycho/vault.json")

class Vault:
    def __init__(self):
        self.salt = None
        self.hash = None
        if os.path.exists(PATH):
            with open(PATH, encoding="utf-8") as f:
                d = json.load(f)
            self.salt = bytes.fromhex(d["salt"])
            self.hash = bytes.fromhex(d["hash"])

    def exists(self):
        return os.path.exists(PATH)

    def create(self, passcode):
        self.salt = secrets.token_bytes(16)
        self.hash = self._derive(passcode, self.salt)
        os.makedirs(os.path.dirname(PATH), exist_ok=True)
        with open(PATH, "w", encoding="utf-8") as f:
            json.dump({"salt": self.salt.hex(), "hash": self.hash.hex()}, f)

    def verify(self, passcode):
        if not self.salt:
            return False
        return hashlib.pbkdf2_hmac("sha256", passcode.encode(), self.salt, 310000) == self.hash

    def _derive(self, passcode, salt):
        return hashlib.pbkdf2_hmac("sha256", passcode.encode(), salt, 310000)
