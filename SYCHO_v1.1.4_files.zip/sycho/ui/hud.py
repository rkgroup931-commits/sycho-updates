from PySide6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QLineEdit, QComboBox, QListWidget, QFileDialog, QMessageBox, QTabWidget,
    QTextEdit, QPlainTextEdit, QDoubleSpinBox, QProgressBar)
from PySide6.QtCore import QTimer, QUrl
from PySide6.QtGui import QDesktopServices
from ..core.engine import SychoEngine

DARK = """
QMainWindow { background-color: #101418; }
QLabel { color: #d8e0e8; font-size: 14px; }
QLineEdit, QComboBox, QTextEdit, QPlainTextEdit, QDoubleSpinBox { background-color: #1a2129; color: #e8eef4; border: 1px solid #2c3642; border-radius: 6px; padding: 6px; }
QPushButton { background-color: #22303c; color: #e8eef4; border: none; border-radius: 6px; padding: 8px 12px; }
QPushButton:hover { background-color: #2c3e4e; }
QListWidget { background-color: #141a20; color: #d8e0e8; border: 1px solid #2c3642; border-radius: 6px; }
QTabWidget::pane { border: 1px solid #2c3642; }
QTabBar::tab { background: #1a2129; color: #d8e0e8; padding: 8px 14px; }
QTabBar::tab:selected { background: #22303c; }
QProgressBar { border: 1px solid #2c3642; border-radius: 6px; background: #1a2129; color: #e8eef4; text-align: center; }
QProgressBar::chunk { background-color: #2f8f5b; }
"""

QUOTES = [
    "Small steps every day build big results.",
    "Focus is the new intelligence.",
    "Discipline is choosing what you want most over what you want now.",
    "Your future is created by what you do today.",
    "Stay consistent; progress follows.",
]

class SychoHud(QMainWindow):
    def __init__(self, engine):
        super().__init__()
        self.engine = engine
        self.setWindowTitle("SYCHO v1.1.4")
        self.setMinimumSize(1040, 720)
        self.setStyleSheet(DARK)
        central = QWidget()
        layout = QVBoxLayout(central)
        title = QLabel("SYCHO AI — v1.1.4")
        title.setStyleSheet("font-size: 20px; font-weight: bold;")
        layout.addWidget(title)

        self.tabs = QTabWidget()
        layout.addWidget(self.tabs)

        memory_tab = QWidget()
        m = QVBoxLayout(memory_tab)
        self.input = QLineEdit()
        self.input.setPlaceholderText("Write something for SYCHO to remember...")
        remember = QPushButton("Remember")
        remember.clicked.connect(self.remember)
        m.addWidget(self.input)
        m.addWidget(remember)
        self.search = QLineEdit()
        self.search.setPlaceholderText("Search your memory...")
        self.search.textChanged.connect(self.refresh_memory)
        self.memory_list = QListWidget()
        delete = QPushButton("Delete Selected Memory")
        delete.clicked.connect(self.delete_memory)
        m.addWidget(self.search)
        m.addWidget(self.memory_list)
        m.addWidget(delete)
        self.tabs.addTab(memory_tab, "Memory")

        notes_tab = QWidget()
        n = QVBoxLayout(notes_tab)
        self.note_title = QLineEdit()
        self.note_title.setPlaceholderText("Note title")
        self.note_body = QTextEdit()
        self.note_body.setPlaceholderText("Write your note here...")
        save_note = QPushButton("Save Note")
        save_note.clicked.connect(self.save_note)
        self.notes_list = QListWidget()
        open_note = QPushButton("Open Selected Note")
        open_note.clicked.connect(self.open_note)
        delete_note = QPushButton("Delete Selected Note")
        delete_note.clicked.connect(self.delete_note)
        export_notes = QPushButton("Export All Notes to TXT")
        export_notes.clicked.connect(self.export_notes)
        n.addWidget(self.note_title)
        n.addWidget(self.note_body)
        n.addWidget(save_note)
        n.addWidget(self.notes_list)
        row_n = QHBoxLayout()
        row_n.addWidget(open_note)
        row_n.addWidget(delete_note)
        row_n.addWidget(export_notes)
        n.addLayout(row_n)
        self.tabs.addTab(notes_tab, "Notes")

        tasks_tab = QWidget()
        t = QVBoxLayout(tasks_tab)
        self.task_input = QLineEdit()
        self.task_input.setPlaceholderText("New task...")
        add_task = QPushButton("Add Task")
        add_task.clicked.connect(self.add_task)
        self.tasks_list = QListWidget()
        done_task = QPushButton("Mark Selected Task Done")
        done_task.clicked.connect(self.complete_task)
        delete_task = QPushButton("Delete Selected Task")
        delete_task.clicked.connect(self.delete_task)
        t.addWidget(self.task_input)
        t.addWidget(add_task)
        t.addWidget(self.tasks_list)
        row_t = QHBoxLayout()
        row_t.addWidget(done_task)
        row_t.addWidget(delete_task)
        t.addLayout(row_t)
        self.tabs.addTab(tasks_tab, "Tasks")

        rem_tab = QWidget()
        r = QVBoxLayout(rem_tab)
        row = QHBoxLayout()
        self.reminder_title = QLineEdit()
        self.reminder_title.setPlaceholderText("Reminder title")
        self.reminder_time = QLineEdit()
        self.reminder_time.setPlaceholderText("Time (YYYY-MM-DD HH:MM)")
        remind = QPushButton("Add Reminder")
        remind.clicked.connect(self.add_reminder)
        row.addWidget(self.reminder_title)
        row.addWidget(self.reminder_time)
        row.addWidget(remind)
        r.addLayout(row)
        self.reminder_list = QListWidget()
        r.addWidget(self.reminder_list)
        self.tabs.addTab(rem_tab, "Reminders")

        focus_tab = QWidget()
        f = QVBoxLayout(focus_tab)
        f.addWidget(QLabel("Pomodoro Focus Timer"))
        row_f = QHBoxLayout()
        self.focus_minutes = QLineEdit("25")
        start_focus = QPushButton("Start Focus")
        start_focus.clicked.connect(self.start_focus)
        stop_focus = QPushButton("Stop")
        stop_focus.clicked.connect(self.stop_focus)
        row_f.addWidget(self.focus_minutes)
        row_f.addWidget(start_focus)
        row_f.addWidget(stop_focus)
        f.addLayout(row_f)
        self.focus_label = QLabel("Ready to focus.")
        self.focus_label.setStyleSheet("font-size: 28px; font-weight: bold;")
        f.addWidget(self.focus_label)
        self.quote_label = QLabel("Daily motivation: " + QUOTES[0])
        self.quote_label.setWordWrap(True)
        f.addWidget(self.quote_label)
        new_quote = QPushButton("New Motivation")
        new_quote.clicked.connect(self.new_quote)
        f.addWidget(new_quote)
        f.addWidget(QLabel("Stopwatch"))
        row_sw = QHBoxLayout()
        sw_start = QPushButton("Start Stopwatch")
        sw_start.clicked.connect(self.start_stopwatch)
        sw_stop = QPushButton("Stop Stopwatch")
        sw_stop.clicked.connect(self.stop_stopwatch)
        sw_reset = QPushButton("Reset")
        sw_reset.clicked.connect(self.reset_stopwatch)
        for b in [sw_start, sw_stop, sw_reset]: row_sw.addWidget(b)
        f.addLayout(row_sw)
        self.stopwatch_label = QLabel("00:00:00")
        self.stopwatch_label.setStyleSheet("font-size: 24px; font-weight: bold;")
        f.addWidget(self.stopwatch_label)
        self.tabs.addTab(focus_tab, "Focus")

        clip_tab = QWidget()
        c = QVBoxLayout(clip_tab)
        c.addWidget(QLabel("Clipboard History (last 20 items)"))
        self.clip_list = QListWidget()
        c.addWidget(self.clip_list)
        refresh_clip = QPushButton("Refresh Clipboard History")
        refresh_clip.clicked.connect(self.refresh_clipboard)
        c.addWidget(refresh_clip)
        self.tabs.addTab(clip_tab, "Clipboard")

        conv_tab = QWidget()
        cv = QVBoxLayout(conv_tab)
        cv.addWidget(QLabel("Unit Converter"))
        row_c = QHBoxLayout()
        self.conv_value = QDoubleSpinBox()
        self.conv_value.setMaximum(999999999)
        self.conv_from = QComboBox()
        self.conv_from.addItems(["km to miles", "miles to km", "kg to lb", "lb to kg", "C to F", "F to C"])
        convert_btn = QPushButton("Convert")
        convert_btn.clicked.connect(self.convert)
        row_c.addWidget(self.conv_value)
        row_c.addWidget(self.conv_from)
        row_c.addWidget(convert_btn)
        cv.addLayout(row_c)
        self.conv_result = QLabel("Result:")
        cv.addWidget(self.conv_result)
        cv.addWidget(QLabel("World Clock (your local time)"))
        self.clock_label = QLabel("")
        self.clock_label.setStyleSheet("font-size: 24px; font-weight: bold;")
        cv.addWidget(self.clock_label)
        self.tabs.addTab(conv_tab, "Tools")

        exp_tab = QWidget()
        e = QVBoxLayout(exp_tab)
        e.addWidget(QLabel("Expense Tracker"))
        row_e = QHBoxLayout()
        self.exp_desc = QLineEdit()
        self.exp_desc.setPlaceholderText("Description")
        self.exp_amount = QDoubleSpinBox()
        self.exp_amount.setMaximum(9999999)
        add_exp = QPushButton("Add Expense")
        add_exp.clicked.connect(self.add_expense)
        row_e.addWidget(self.exp_desc)
        row_e.addWidget(self.exp_amount)
        row_e.addWidget(add_exp)
        e.addLayout(row_e)
        self.exp_list = QListWidget()
        e.addWidget(self.exp_list)
        self.exp_total = QLabel("Total: 0")
        e.addWidget(self.exp_total)
        self.tabs.addTab(exp_tab, "Expenses")

        tools_tab = QWidget()
        tl = QVBoxLayout(tools_tab)
        self.calc_input = QLineEdit()
        self.calc_input.setPlaceholderText("Calculator: e.g. 12*(3+4)")
        calc = QPushButton("Calculate")
        calc.clicked.connect(self.calculate)
        self.calc_result2 = QLabel("Result:")
        gen_pass = QPushButton("Generate Strong Password")
        gen_pass.clicked.connect(self.generate_password)
        self.password_label = QLabel("Password:")
        self.sysinfo = QPlainTextEdit()
        self.sysinfo.setReadOnly(True)
        sysinfo_btn = QPushButton("Show System Info")
        sysinfo_btn.clicked.connect(self.show_sysinfo)
        tl.addWidget(self.calc_input)
        tl.addWidget(calc)
        tl.addWidget(self.calc_result2)
        tl.addWidget(gen_pass)
        tl.addWidget(self.password_label)
        tl.addWidget(sysinfo_btn)
        tl.addWidget(self.sysinfo)
        self.tabs.addTab(tools_tab, "Advanced")

        quick_tab = QWidget()
        q = QVBoxLayout(quick_tab)
        q.addWidget(QLabel("Quick Launch — open your favorite sites"))
        row_q1 = QHBoxLayout()
        yt = QPushButton("YouTube")
        gm = QPushButton("Gmail")
        gh = QPushButton("GitHub")
        yt.clicked.connect(lambda: QDesktopServices.openUrl(QUrl("https://youtube.com")))
        gm.clicked.connect(lambda: QDesktopServices.openUrl(QUrl("https://mail.google.com")))
        gh.clicked.connect(lambda: QDesktopServices.openUrl(QUrl("https://github.com")))
        for b in [yt, gm, gh]: row_q1.addWidget(b)
        q.addLayout(row_q1)
        row_q2 = QHBoxLayout()
        gpt = QPushButton("ChatGPT")
        maps = QPushButton("Google Maps")
        weather = QPushButton("Weather")
        gpt.clicked.connect(lambda: QDesktopServices.openUrl(QUrl("https://chat.openai.com")))
        maps.clicked.connect(lambda: QDesktopServices.openUrl(QUrl("https://maps.google.com")))
        weather.clicked.connect(lambda: QDesktopServices.openUrl(QUrl("https://weather.com")))
        for b in [gpt, maps, weather]: row_q2.addWidget(b)
        q.addLayout(row_q2)
        self.quick_url = QLineEdit()
        self.quick_url.setPlaceholderText("Type any website, e.g. example.com")
        open_url = QPushButton("Open Website")
        open_url.clicked.connect(self.open_custom_url)
        q.addWidget(self.quick_url)
        q.addWidget(open_url)
        q.addWidget(QLabel("Web Search"))
        self.web_search = QLineEdit()
        self.web_search.setPlaceholderText("Search Google, e.g. python tutorial")
        search_btn = QPushButton("Search Google")
        search_btn.clicked.connect(self.web_search_go)
        q.addWidget(self.web_search)
        q.addWidget(search_btn)
        self.tabs.addTab(quick_tab, "Quick Launch")

        updates_tab = QWidget()
        u = QVBoxLayout(updates_tab)
        u.addWidget(QLabel("SYCHO One-Click Updater"))
        self.update_status = QLabel("Checking for updates...")
        self.update_status.setWordWrap(True)
        u.addWidget(self.update_status)
        self.update_notes = QLabel("")
        self.update_notes.setWordWrap(True)
        u.addWidget(self.update_notes)
        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        u.addWidget(self.progress)
        one_click = QPushButton("DOWNLOAD & INSTALL UPDATE")
        one_click.setStyleSheet("font-size: 16px; padding: 12px;")
        one_click.clicked.connect(self.one_click_update)
        u.addWidget(one_click)
        open_latest = QPushButton("Open Updated SYCHO Folder")
        open_latest.clicked.connect(self.open_latest)
        u.addWidget(open_latest)
        self.tabs.addTab(updates_tab, "Updates")

        row2 = QHBoxLayout()
        self.language = QComboBox()
        self.language.addItems(["en", "ur", "ps", "hi", "tr"])
        self.language.currentTextChanged.connect(self.change_language)
        backup = QPushButton("Backup Memory")
        restore = QPushButton("Restore Memory")
        stop = QPushButton("EMERGENCY STOP")
        backup.clicked.connect(self.backup)
        restore.clicked.connect(self.restore)
        stop.clicked.connect(self.emergency_stop)
        row2.addWidget(self.language)
        row2.addWidget(backup)
        row2.addWidget(restore)
        row2.addWidget(stop)
        layout.addLayout(row2)

        self.status = QLabel("Unlocked")
        layout.addWidget(self.status)
        self.setCentralWidget(central)
        self.refresh_memory()
        self.refresh_reminders()
        self.refresh_notes()
        self.refresh_tasks()
        self.refresh_clipboard()
        self.refresh_expenses()
        self.pending_update = None
        self.focus_seconds_left = 0
        self.focus_timer = QTimer()
        self.focus_timer.timeout.connect(self.tick_focus)
        self.clock_timer = QTimer()
        self.clock_timer.timeout.connect(self.update_clock)
        self.clock_timer.start(1000)
        self.update_clock()
        self.stopwatch_seconds = 0
        self.stopwatch_timer = QTimer()
        self.stopwatch_timer.timeout.connect(self.tick_stopwatch)
        QTimer.singleShot(1500, self.auto_check_updates)

    def auto_check_updates(self):
        data = self.engine.updates.check()
        if data:
            self.pending_update = data
            self.update_status.setText("Update available: SYCHO v" + str(data.get("version")) + ". Click DOWNLOAD & INSTALL UPDATE.")
            self.update_notes.setText("What is new: " + str(data.get("notes", "")))
        else:
            self.update_status.setText("You are up to date.")
            self.update_notes.setText("")

    def one_click_update(self):
        if not self.pending_update:
            self.update_status.setText("No update found yet. Wait a moment or restart SYCHO.")
            return
        self.progress.setValue(10)
        self.update_status.setText("Downloading update...")
        try:
            self.engine.updates.download_and_install(
                self.pending_update["url"],
                self.pending_update.get("sha256"),
                self.progress)
            self.progress.setValue(100)
            self.update_status.setText("UPDATE INSTALLED to C:\\SYCHO\\latest — Restart SYCHO from that folder to use v" + str(self.pending_update.get("version")) + ".")
        except Exception as e:
            self.progress.setValue(0)
            self.update_status.setText("Update failed: " + str(e))

    def open_latest(self):
        import os
        path = self.engine.updates.latest_folder
        if os.path.exists(path):
            QDesktopServices.openUrl(QUrl.fromLocalFile(path))
        else:
            self.update_status.setText("No updated folder yet. Install an update first.")

    def web_search_go(self):
        text = self.web_search.text().strip()
        if text:
            from urllib.parse import quote_plus
            QDesktopServices.openUrl(QUrl("https://www.google.com/search?q=" + quote_plus(text)))
            self.status.setText("Searching Google: " + text)

    def export_notes(self):
        if not self.engine.get_notes():
            self.status.setText("No notes to export.")
            return
        file, _ = QFileDialog.getSaveFileName(self, "Export Notes", "SYCHO_notes.txt", "Text files (*.txt)")
        if file:
            with open(file, "w", encoding="utf-8") as f:
                for note in self.engine.get_notes():
                    f.write("=== " + note["title"] + " ===\n" + note["body"] + "\n\n")
            self.status.setText("Notes exported to: " + file)

    def start_stopwatch(self):
        self.stopwatch_timer.start(1000)

    def stop_stopwatch(self):
        self.stopwatch_timer.stop()

    def reset_stopwatch(self):
        self.stopwatch_timer.stop()
        self.stopwatch_seconds = 0
        self.stopwatch_label.setText("00:00:00")

    def tick_stopwatch(self):
        self.stopwatch_seconds += 1
        h = self.stopwatch_seconds // 3600
        mnt = (self.stopwatch_seconds % 3600) // 60
        sec = self.stopwatch_seconds % 60
        self.stopwatch_label.setText(str(h).zfill(2) + ":" + str(mnt).zfill(2) + ":" + str(sec).zfill(2))

    def remember(self):
        text = self.input.text().strip()
        if text:
            self.engine.remember(text)
            self.status.setText("Saved to encrypted memory")
            self.input.clear()
            self.refresh_memory()

    def refresh_memory(self):
        self.memory_list.clear()
        q = self.search.text().strip().lower()
        for item in self.engine.all_memory():
            text = item.get("text", "")
            if not q or q in text.lower():
                self.memory_list.addItem(text)

    def delete_memory(self):
        row = self.memory_list.currentRow()
        if row >= 0:
            text = self.memory_list.item(row).text()
            self.engine.delete_memory(text)
            self.refresh_memory()
            self.status.setText("Memory deleted")

    def save_note(self):
        title = self.note_title.text().strip()
        body = self.note_body.toPlainText().strip()
        if title and body:
            self.engine.save_note(title, body)
            self.status.setText("Note saved")
            self.note_title.clear()
            self.note_body.clear()
            self.refresh_notes()

    def refresh_notes(self):
        self.notes_list.clear()
        for note in self.engine.get_notes():
            self.notes_list.addItem(note["title"])

    def open_note(self):
        row = self.notes_list.currentRow()
        if row >= 0:
            note = self.engine.get_notes()[row]
            self.note_title.setText(note["title"])
            self.note_body.setPlainText(note["body"])
            self.status.setText("Note opened")

    def delete_note(self):
        row = self.notes_list.currentRow()
        if row >= 0:
            title = self.notes_list.item(row).text()
            self.engine.delete_note(title)
            self.refresh_notes()
            self.status.setText("Note deleted")

    def add_task(self):
        text = self.task_input.text().strip()
        if text:
            self.engine.add_task(text)
            self.task_input.clear()
            self.refresh_tasks()
            self.status.setText("Task added")

    def refresh_tasks(self):
        self.tasks_list.clear()
        for task in self.engine.get_tasks():
            mark = "[done] " if task["done"] else ""
            self.tasks_list.addItem(mark + task["text"])

    def complete_task(self):
        row = self.tasks_list.currentRow()
        if row >= 0:
            self.engine.complete_task(row)
            self.refresh_tasks()

    def delete_task(self):
        row = self.tasks_list.currentRow()
        if row >= 0:
            self.engine.delete_task(row)
            self.refresh_tasks()

    def add_reminder(self):
        title = self.reminder_title.text().strip()
        when = self.reminder_time.text().strip()
        if title and when:
            self.engine.add_reminder(title, when)
            self.status.setText("Reminder saved")
            self.reminder_title.clear()
            self.reminder_time.clear()
            self.refresh_reminders()

    def refresh_reminders(self):
        self.reminder_list.clear()
        for r in self.engine.get_reminders():
            self.reminder_list.addItem(r["when"] + " - " + r["title"])

    def start_focus(self):
        try:
            minutes = max(1, int(self.focus_minutes.text()))
        except Exception:
            self.focus_label.setText("Enter a valid number of minutes.")
            return
        self.focus_seconds_left = minutes * 60
        self.focus_timer.start(1000)
        self.tick_focus()

    def stop_focus(self):
        self.focus_timer.stop()
        self.focus_label.setText("Focus stopped.")

    def tick_focus(self):
        if self.focus_seconds_left <= 0:
            self.focus_timer.stop()
            self.focus_label.setText("Focus complete! Take a short break.")
            return
        minutes, seconds = divmod(self.focus_seconds_left, 60)
        self.focus_label.setText(str(minutes).zfill(2) + ":" + str(seconds).zfill(2))
        self.focus_seconds_left -= 1

    def new_quote(self):
        import random
        self.quote_label.setText("Daily motivation: " + random.choice(QUOTES))

    def refresh_clipboard(self):
        self.clip_list.clear()
        for item in self.engine.clipboard_history():
            self.clip_list.addItem(item)

    def convert(self):
        v = self.conv_value.value()
        mode = self.conv_from.currentText()
        if mode == "km to miles": result = v * 0.621371
        elif mode == "miles to km": result = v * 1.60934
        elif mode == "kg to lb": result = v * 2.20462
        elif mode == "lb to kg": result = v * 0.453592
        elif mode == "C to F": result = v * 9/5 + 32
        else: result = (v - 32) * 5/9
        self.conv_result.setText("Result: " + str(round(result, 4)))

    def update_clock(self):
        from datetime import datetime
        self.clock_label.setText(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

    def add_expense(self):
        desc = self.exp_desc.text().strip()
        amount = self.exp_amount.value()
        if desc and amount > 0:
            self.engine.add_expense(desc, amount)
            self.exp_desc.clear()
            self.exp_amount.setValue(0)
            self.refresh_expenses()
            self.status.setText("Expense added")

    def refresh_expenses(self):
        self.exp_list.clear()
        total = 0
        for exp in self.engine.get_expenses():
            self.exp_list.addItem(exp["description"] + ": " + str(exp["amount"]))
            total += exp["amount"]
        self.exp_total.setText("Total: " + str(round(total, 2)))

    def calculate(self):
        try:
            allowed = set("0123456789+-*/(). ")
            expr = self.calc_input.text()
            if expr and set(expr) <= allowed:
                self.calc_result2.setText("Result: " + str(eval(expr)))
            else:
                self.calc_result2.setText("Only numbers and + - * / ( ) are allowed.")
        except Exception:
            self.calc_result2.setText("Invalid calculation.")

    def generate_password(self):
        import secrets, string
        alphabet = string.ascii_letters + string.digits + "!@#$%^&*()-_=+"
        password = "".join(secrets.choice(alphabet) for _ in range(20))
        self.password_label.setText("Password: " + password)

    def show_sysinfo(self):
        import platform
        info = "OS: " + platform.system() + " " + platform.release()
        info += "\nMachine: " + platform.machine()
        info += "\nPython: " + platform.python_version()
        self.sysinfo.setPlainText(info)

    def open_custom_url(self):
        url = self.quick_url.text().strip()
        if url:
            if not url.startswith("http"):
                url = "https://" + url
            QDesktopServices.openUrl(QUrl(url))
            self.status.setText("Opened: " + url)

    def change_language(self, code):
        self.engine.set_language(code)
        self.status.setText("Language: " + code)

    def backup(self):
        folder = QFileDialog.getExistingDirectory(self, "Choose backup folder")
        if folder:
            self.engine.backup(folder)
            self.status.setText("Backup created")

    def restore(self):
        file, _ = QFileDialog.getOpenFileName(self, "Choose memory backup", "", "Encrypted memory (*.enc)")
        if file:
            self.engine.restore(file)
            self.refresh_memory()
            self.status.setText("Memory restored")

    def emergency_stop(self):
        reply = QMessageBox.question(self, "Emergency Stop", "Stop SYCHO now?", QMessageBox.Yes | QMessageBox.No)
        if reply == QMessageBox.Yes:
            self.engine.emergency_stop()
            self.close()

import os
