SYCHO v1.1.4 - ONE-CLICK UPDATER

New: Download & Install button does everything automatically.
Updates install to C:\SYCHO\latest - no folder choosing, no WinRAR.

Build:
pip install --default-timeout=100 --retries 10 -r requirements.txt pyinstaller
pyinstaller --noconsole --onefile --name SYCHO run.py
Open dist\SYCHO.exe
