import sys, traceback, os
from datetime import datetime

def show_error(exc_type, exc_value, exc_tb):
    text = "".join(traceback.format_exception(exc_type, exc_value, exc_tb))
    log = os.path.expanduser("~/.sycho/error.log")
    os.makedirs(os.path.dirname(log), exist_ok=True)
    with open(log, "a", encoding="utf-8") as f:
        f.write(datetime.now().isoformat() + "\n" + text + "\n\n")
    try:
        from PySide6.QtWidgets import QApplication, QMessageBox
        app = QApplication.instance() or QApplication(sys.argv)
        QMessageBox.critical(None, "SYCHO Error", text[-3000:])
    except Exception:
        print(text)
    sys.exit(1)

sys.excepthook = show_error

def main():
    from sycho.app import start
    start()

if __name__ == "__main__":
    main()
