@echo off
python -m venv .venv
call .venv\Scripts\activate
pip install --default-timeout=100 --retries 10 -r requirements.txt pyinstaller
pyinstaller --noconsole --onefile --name SYCHO run.py
echo.
echo Done. Open dist\SYCHO.exe
pause
